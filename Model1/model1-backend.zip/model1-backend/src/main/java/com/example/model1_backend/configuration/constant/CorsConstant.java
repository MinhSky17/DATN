package com.example.model1_backend.configuration.constant;

import java.util.ArrayList;
import java.util.List;

public final class CorsConstant {

    public static final List<String> LIST_DOMAIN_ACCEPT
            = new ArrayList<>(
            List.of("http://localhost:3001"));

}
