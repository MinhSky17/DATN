package com.example.model1_backend.controller.admin;

import com.example.model1_backend.common.base.PageableObject;
import com.example.model1_backend.dto.request.ApiResponse;
import com.example.model1_backend.dto.request.UserCreationRequest;
import com.example.model1_backend.dto.request.UserUpdateRequest;
import com.example.model1_backend.dto.response.UserResponse;
import com.example.model1_backend.service.UserService;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@Slf4j
@RestController
@RequestMapping("/admin/user")
public class UserController {
    @Autowired
    private UserService userService;

    @PostMapping()
    ApiResponse<UserResponse> createUser(@RequestBody @Valid UserCreationRequest request){
        ApiResponse<UserResponse> apiResponse = new ApiResponse<>();

        apiResponse.setResult(userService.createUser(request));
        return apiResponse;
    }

//    @GetMapping()
//    ApiResponse<List<UserResponse>> getUsers(){
//        var authentication = SecurityContextHolder.getContext().getAuthentication();
//
//        log.info("Username: {}", authentication.getName());
//        authentication.getAuthorities().forEach(grantedAuthority -> log.info(grantedAuthority.getAuthority()));
//
//        return ApiResponse.<List<UserResponse>>builder()
//                .code(1000)
//                .result(userService.getUsers())
//                .build();
//    }

    @GetMapping()
    public PageableObject<Map<Object, Object>> getUser(Pageable pageable){
        return userService.getAllUser(pageable);
    }

//    @GetMapping
//    public PageableObject<AdUserCoinInfoResponse> getPage(final AdFindUserCoinInfoRequest request) {
//        return adUserCoinInfoService.getPage(request);
//    }

//    List<User> getUser(){
//        return userService.getUsers();
//    }

    @GetMapping("/{userId}")
    ApiResponse<UserResponse> getUser(@PathVariable("userId") String userId){
        return ApiResponse.<UserResponse>builder()
                .code(1000)
                .result(userService.getUser(userId))
                .build();
    }

    @GetMapping("/myInfo")
    ApiResponse<UserResponse> getMyInfo(){
        return ApiResponse.<UserResponse>builder()
                .code(1000)
                .result(userService.getMyInfo())
                .build();
    }

    @PutMapping("/{userId}")
    UserResponse updateUser(@PathVariable("userId") String userId, @RequestBody UserUpdateRequest request){
        return userService.updateUser(userId, request);
    }

    @DeleteMapping("/{userId}")
    String deleteUser(@PathVariable("userId") String userId){
        userService.deteleUser(userId);
        return "User has been deleted";
    }
}
