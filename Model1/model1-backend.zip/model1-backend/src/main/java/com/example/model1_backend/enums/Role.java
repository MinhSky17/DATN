package com.example.model1_backend.enums;

public enum Role {
    ADMIN,
    USER
}
