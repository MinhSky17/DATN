package com.example.model1_backend.dto.response;

import com.example.model1_backend.enums.Role;
import lombok.*;
import lombok.experimental.FieldDefaults;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Set;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)

public class UserResponse {
    String id;
    int roleId = 0;
    String username;
    String firstName;
    String lastName;
    LocalDate dateOfBirth;
    String email;
    String phoneNumber;
    String gender;
    String address;
    Boolean active;
    LocalDateTime createdAt;
    LocalDateTime updatedAt;
    Role role;
}
