package com.example.model1_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Model1BackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
