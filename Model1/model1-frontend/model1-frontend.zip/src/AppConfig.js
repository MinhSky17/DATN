

export const AppConfig = {
  // apiUrl: process.env.REACT_APP_API_URL,
  // //apiUrl: "http://localhost:8080/coshine",
  // routerBase: "",
  apiUrl: "",
};
