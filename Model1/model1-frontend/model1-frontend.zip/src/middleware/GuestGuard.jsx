const GuestGuard = ({ children }) => {
    return children;
};

export default GuestGuard;