import styles from "./brandManagement.module.css";

const BrandManagement = () => {
  return <div className={styles.brandContainer}>Brand Management 1</div>;
};

export default BrandManagement;
