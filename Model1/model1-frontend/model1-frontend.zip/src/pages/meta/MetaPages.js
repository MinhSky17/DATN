const MetaPages = () => {
  return <div></div>;
};

export default MetaPages;
