export const SCREEN = {
  brandManagement: {
    path: "/brand-management",
  },
};
