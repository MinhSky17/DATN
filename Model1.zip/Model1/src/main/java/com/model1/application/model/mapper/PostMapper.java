package com.model1.application.model.mapper;

public class PostMapper {
}
